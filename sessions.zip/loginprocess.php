<?php
session_start ();
//include("config.php"); 

$hostnameORip = "198.71.225.54:3306";
$databaseName = "user";
$username = "session";
$password = "76wod1*K";
$connectionString = "mysql:host=".$hostnameORip.";dbname=".$databaseName.";";
try{
    $db = new PDO($connectionString, $username, $password);
 }catch(Exception $e){
    echo "<pre>".print_r($e, true)."</pre>";//this should give you any errors that occurred trying to connect to the database
 }

if(isset($_POST['sub']))
{
$user = $_POST['username'];
$password = $_POST['password'];

echo $user;
echo $password;
$q = "SELECT * FROM user_login WHERE username='$user' AND pass='$password'";

$query = $db->query($q);
//echo $query;
if($query)
{
    $results = $query->fetchAll(PDO::FETCH_ASSOC);
    echo print_r($results);
if(isset($results))
{
	
	$_SESSION["login"]=$user;
	header("location:index.php");
}
else	
{
	header("location:login.php?err=1");
	
}
}
}
//*/
?>
