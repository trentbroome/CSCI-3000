<?php
session_start();
$host = " 198.71.225.54:3306"; /* Host name */
$user = "session"; /* User */
$password = "76wod1*K"; /* Password */
$dbname = "user"; /* Database name */
$mysqli = mysqli_connect($host, $user, $password, $dbname);
 
?>