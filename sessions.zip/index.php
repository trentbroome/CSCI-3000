<?php
session_start ();
if(!isset($_SESSION["login"]))

    header("location:login.php"); 
?>
<body>
    <?php
    	if(isset($_SESSION['username']))
        {
            echo "<h1>Hello ".$_SESSION['username']."</h1>";
        }
    ?>
<h1>Hey ! welcome to main page</h1>

<a href="logout.php"><h2>Logout</h2>
    </body>