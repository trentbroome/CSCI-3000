<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>MySQL assignment</title>
<link rel="stylesheet" type="text/css" href="phpCSS.css"/>

</head>

<body>
<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

$hostnameORip = "198.71.255.54:3306";
$databaseName = "ph12975858231";
$username = "mySQLdatabase";
$password = "@5Raqk05";
$connectionString = "mysql:host=".$hostnameORip.";dbname=".$databaseName.";";
try{
    $db = new PDO($connectionString, $username, $password);
 }catch(Exception $e){
    echo "<pre>".print_r($e, true)."</pre>";//this should give you any errors that occurred trying to connect to the database
 }
 ?>
	<?php
 $complete = true;
	if(isset($_POST["submitButton"]))//submit button was clicked
	{
		echo "form submitted<br>";
		$errors = "";
		if(isset($_POST["name"]) && strlen(trim($_POST["name"])) > 0)
		{
			//successful validation
            echo "Name submitted";
		}
		else
		{
            $errors .= "First name not completed<br>";
	}
		if(isset($_POST["email"]) && strlen(trim($_POST["email"])) > 0)
		{
			//successful validation
			echo "Email submitted";
		}
		else
		{
            $errors .= "Email not completed<br>";
		}
		if(isset($_POST["sport"]) && strlen(trim($_POST["sport"])) > 0)
		{
			//successful validation
			echo "Favorite Sport submitted";
		}
		else
		{
            $errors .= "Sport not completed<br>";
		}
				if(isset($_POST["team"]) && strlen(trim($_POST["team"])) > 0)
		{
			//successful validation
			echo "Favorite team submitted";
		}
		else
		{
            $errors .= "Team not completed<br>";
		}
		
		//all validation steps complete
		if(strlen($errors) > 0)
		{
			echo "<div class='errors'>";
			echo $errors;
			echo "</div>";
		}
		else
		{
			echo "No errors in submission";//insert into database
		}
		?>

	

	<form action="" method="post">
	
		<label for="name">Name</label>
		<input type="text" name="name" id="name" 
			   value="">
		<br>
		
		<label for="email">Email: </label>
		<input type="text" name="email" id="email"
			   value="">
        <br>
		<label for="sport">Favorite Sport: </label>
		<input type="text" name="sport" id="sport"
			   value="">
        <br>
		<label for="team">Favorite Sports Team: </label>
		<input type="text" name="team" id="team"
			   value="">
        <br>
		<input type="submit" name="submitButton" value="Submit Form">

	</form>
    <?php if ($complete){ ?>
<table class="table table-striped table-dark">
        <thead>
          <tr>
            <th scope="col">Name: </th>
            <th scope="col">Email: </th>
            <th scope="col">Sport: </th>
            <th scope="col">Team: </th>
          </tr>
        </thead>
        <tbody>
          <tr>
    <td><?php echo $_POST['name']; ?></td>
    <td><?php echo $_POST['email']; ?></td>
    <td><?php echo $_POST['sport']; ?></td>
    <td><?php echo $_POST['team']; ?></td>
          </tr>
<?php } ?>
<?php
$insert = $db->prepare("INSERT INTO myTable (first, email, sport, team) VALUES (?, ?, ?, ?)");
$insert->bindParam(1,$name);
$insert->bindParam(2,$email);
$insert->bindParam(3,$sport);
$insert->bindParam(4,$team);
$insert->execute();
$query = $db->query("SELECT * FROM myTable");
$results = $query->fetchAll();

?>
</body>
</html>