<?php
session_start();

if(!isset($_SESSION['name'])) {
    header("Location: index.php");
    exit();
}
?>
<? include "footer.php"?>
<?include "header.php"?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Final Project</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="finalStyle.css"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="home.js"></script>
	<script>
		$(document).ready(function(){
            $('#select').change(function(){
				$.ajax({
					url: "AJAXresponse.php?q="+$('#select').val(),
					context: document.body
				}).done(function(data) {
					console.log(data);
					$("#resultsHtml").html(data);
				});
				
				$.getJSON( "AJAXresponse.php?type=json&q="+$('#select').val(), function( data ) {
					console.log(data);
					console.log(data['name']);
					content = "JSON<table id='select'class = 'steelBlueColsJson'><thead><tr><th>ID</th><th>Name</th><th>City</th><th>State</th></tr></thead><tbody><tr><td>"+ data['id'] +"</td><td>"+ data['name'] +"</td><td>"+ data['city'] +"</td><td>"+ data['state'] +"</td</tr></tbody></table>";
					$("#resultsJson").html(content);
				});
                console.log($('#select').val());
            });
		});
		
	</script>
</head>

<body>
	<h1 id= "mascots">Pick a mascot!</h1>
  <select name="mascots" id='select'>
    <option value="">Select a Mascot:</option>
    <option value="nigel">Nigel Nighthawk</option>
    <option value="maxi ">Maximus Lion</option>
    <option value="buzz">Buzz yellow jacket</option>
  </select>
	<div id="resultsHtml">
		
	</div>
	<div id="resultsJson">
		
	</div>
</body>
</html>