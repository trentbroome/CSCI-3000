<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Final Project</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="finalStyle.css"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="home.js"></script>
<body>
<form method="POST">
    <div class="container mt-5">
        <div class="row">

            <div class="col-4">
                <label>First Name:</label>
                <input type="text" name="first_name" class="form-control">

            </div>
            <div class="col-4">
                <label>Last Name:</label>
                <input type="text" name="last_name" class="form-control">

            </div>
            <div class="col-4">
                <label>Email:</label>
                <input type="text" name="email" class="form-control">

            </div>
            <div class="col-4">
                <label>Class Status:</label>
                <select name="class_status" class="form-control">
                    <option value="" selected>---------</option>
                    <option value='Freshman'>Freshman</option>
                    <option value='Sophomore'>Sophomore</option>
                    <option value='Junior'>Junior</option>
                    <option value='Senior'>Senior</option>
                </select>

            </div>
            <div class="col-4">
                <label>Major Status:</label>
                <select name="major" class="form-control">
                    <option value="" selected>---------</option>
                    <option value='Computer Science'>Computer Science</option>
                    <option value='Math'>Math</option>
                    <option value='Physics'>Physics</option>
                    <option value='Nursing'>nursing</option>
                    <option value='other'>other</option>

                </select>

            </div>
            <div class="col-4 mt-4">
                <button type="submit" class="btn btn-success btn-block">Submit</button>
            </div>
        </div>

        <div class="row">
            <div class="col-12">

                <?php
$hostnameORip = "198.71.225.54:3306";
$databaseName = "ph12975858231__";
$username = "trentbroome";
$password = "Pj5w2j?7";
$connectionString = "mysql:host=".$hostnameORip.";dbname=".$databaseName.";";
try{
    $db = new PDO($connectionString, $username, $password);
 }catch(Exception $e){
    echo "<pre>".print_r($e, true)."</pre>";//this should give you any errors that occurred trying to connect to the database
 }
 
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                    $values = array(
                        "first_name" => $_POST["first_name"],
                        "last_name" => $_POST["last_name"],
                        "email" => $_POST["email"],
                        "class_status" => $_POST["class_status"],
                        "major" => $_POST["major"],
                    );
                    $validated = array(
                        "first_name" => false,
                        "last_name" => false,
                        "email" => false,
                        "class_status" => false,
                        "major" => false,
                    );
                    $all_valid = true;

                    foreach ($values as $key => $value) {
                        if ($value == "") {
                            $all_valid = false;
                        } else {
                            $validated[$key] = true;
                        }
                    }

                    if ($all_valid) {

                        $query = $db->prepare("INSERT INTO myTable (first_name, last_name, email,
						class_status, major_status)
						VALUES  (?, ?, ?, ?, ?)");
                        $query->bindParam(1, $values['first_name']);
                        $query->bindParam(2, $values['last_name']);
                        $query->bindParam(3, $values['email']);
                        $query->bindParam(4, $values['class_status']);
                        $query->bindParam(5, $values['major']);

                        $query->execute();

                    } else {
                        echo("Errors: <br>");
                        if (!$validated['first_name']) echo('First name is required.<br>');
                        if (!$validated['last_name']) echo('Last name is required.<br>');
                        if (!$validated['email']) echo('Email is required.<br>');
                        if (!$validated['class_status']) echo('Class status is required.<br>');
                        if (!$validated['major']) echo('Major status is required.<br>');
                    }
                }

                $sql = $db->prepare("SELECT * FROM myTable");
                $sql->execute();
                $result = $sql->fetchAll(PDO::FETCH_ASSOC);


                if (sizeof($result) > 0) {
                    // set up table html
                    echo "<table class='table mt-5'>
						<thead>
							<tr>
								<th>Name</th>
								<th>Email</th>
								<th>Class</th>
								<th>major</th>
							</tr>
						</thead>
						<tbody>
							";
                    // output data of each row
                    foreach ($result as $row) {
                        echo "
					<tr>
						<td>" . $row['first_name'] . " " . $row['last_name'] . "</td>
						<td>" . $row['email'] . "</td>
						<td>" . $row['class_status'] . "</td>
						<td>" . $row['major_status'] . "</td>
					</tr>
					
					";
                    }
                    // close table html
                    echo "</tbody></table>";
                } else {
                    echo "<div class='text-center display-4 mt-5'>0 results</div>";
                }
                $conn->close();


                ?>

            </div>
        </div>
    </div>
</form>
</body>
</html>
	













