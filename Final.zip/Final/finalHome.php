<?php
session_start();

if(!isset($_SESSION['name'])) {
    header("Location: index.php");
    exit();
}
?>
<? include "footer.php"?>
<?include "header.php"?>

<?php
$host = "198.71.225.54:3306";
$username = "trentbroome";
$password = "Pj5w2j?7";
$database = "ph12975858231__";
try {
    $db = new PDO("mysql:host=$host; dbname=$database;", $username, $password);
} catch (Exception $e) {}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="finalStyle.css"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="home.js"></script>
<title>Final Project</title>
</head>
<body>
  <div class="content">
    <div class="content-inside">
		<h3 id = "center">Trent Broome</h3>
				<h3 id = "center">Future Web Developer</h3>
		<h6 id = "centered">I am gonna finish this class out i started it.... With a super sweet otter picture!</h6>
		<img id  = "otter" src="https://i.imgur.com/w6N6enh.jpg" alt="chewy Otter">
    </div>
  </div>
  <footer class="footer"></footer>
</body>
</html>