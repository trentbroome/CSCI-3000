<?php
session_start();

if(!isset($_SESSION['name'])) {
    header("Location: index.php");
    exit();
}
?>
<? include "footer.php"?>
<?include "header.php"?>

<?php

$host = "198.71.225.54:3306";
$username = "trentbroome";
$password = "Pj5w2j?7";
$database = "ph12975858231__";
try {
    $db = new PDO("mysql:host=$host; dbname=$database;", $username, $password);
} catch (Exception $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $vote_option = $_POST['vote_option'];
    $error_msg = '';

    if ($vote_option != '') {
        $queryins = $db->prepare("INSERT INTO votes (vote_option) VALUES (?)");
        $queryins->bindParam(1, $vote_option);

        $queryins->execute();
    } else {
        $error_msg = 'Please choose a valid option.';
    }
}

$query = $db->prepare("SELECT * FROM votes");

$query->execute();
$results = $query->fetchAll(PDO::FETCH_ASSOC);

$count1 = 0;
$count2 = 0;
$count3 = 0;
$count4 = 0;
$count5 = 0;
$count6 = 0;

foreach ($results as $vote) {
    if ($vote['vote_option'] == 1) $count1++;
    if ($vote['vote_option'] == 2) $count2++;
    if ($vote['vote_option'] == 3) $count3++;
    if ($vote['vote_option'] == 4) $count4++;
    if ($vote['vote_option'] == 5) $count5++;
    if ($vote['vote_option'] == 6) $count6++;

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Final Project</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="finalStyle.css"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="home.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script type="text/javascript">

        // Load the Visualization API and the corechart package.
        google.charts.load('current', {'packages':['corechart']});

        // Set a callback to run when the Google Visualization API is loaded.
        google.charts.setOnLoadCallback(drawChart);

        // Callback that creates and populates a data table,
        // instantiates the pie chart, passes in the data and
        // draws it.
        function drawChart() {
            const rows = [
                ['Hockey', <? echo $count1 ?>],
                ['Football', <? echo $count2 ?>],
                ['Baseball', <? echo $count3 ?>],
                ['Soccer', <? echo $count4 ?>],
                ['Basketball', <? echo $count5 ?>],
                ['Other', <? echo $count6 ?>]
            ]

            // Create the data table.
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Topping');
            data.addColumn('number', 'Slices');
            data.addRows(rows);

            // Set chart options
            var options = {'title':'Favorite Sport:',
                'width':600,
                'height':400};

            // Instantiate and draw our chart, passing in some options.
            var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }
    </script>

</head>

<body>
<div class="container">
    <div class="row mt-5 mb5">
        <div class="col-4">
            <form method="POST">
                <label for="vote_option">Favorite sport:</label>
                <? if($error_msg != '') echo "<div class='alert alert-danger'>".$error_msg."</div>" ?>
                <select class="form-control" name="vote_option" id="vote_option">
                    <option value="">------</option>
                    <option value="1">Hockey</option>
                    <option value="2">Football</option>
                    <option value="3">Baseball</option>
                    <option value="4">Soccer</option>                    
                    <option value="5">Basketball</option>
                    <option value="6">Other</option>
                </select>
                <br>
                <button type="submit" class="btn btn-primary">Submit Vote</button>
            </form>
        </div>
        <div class="col-8">
            <div id="chart_div"></div>
        </div>
    </div>
</div>

</body>

</html>
