<?php
session_start();

if(!isset($_SESSION['name'])) {
    header("Location: index.php");
    exit();
}
?>
<? include "footer.php"?>
<?include "header.php"?>

<?php
$host = "198.71.225.54:3306";
$username = "trentbroome";
$password = "E%6jrx40";
$database = "ph12975858231__";
try {
    $db = new PDO("mysql:host=$host; dbname=$database;", $username, $password);
} catch (Exception $e) {}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="finalStyle.css"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="home.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
   integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
   crossorigin=""/>
	
	
	<!-- Make sure you put this AFTER Leaflet's CSS -->
 <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
   integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
   crossorigin=""></script>
	
	
	<style>
	#mapid { height: 600px; }
	</style>
	
<title>Final Project</title>
</head>
<body>
		<h3>Have you ever wondered where all of the NHL teams are located?</h3>
	<h6>Click on the markers to see where teams are located, in what arenas they play in, and what division they are in!</h6>
<div id = "mapid"></div>

<script>
	var mymap = L.map('mapid').setView([34.528542, -83.986294], 16);//where the map is centered and default zoom level
		
		
	L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoiamV0dHVybmVyIiwiYSI6ImNrMnZjNjBveTAza3MzY3FoM2JnZTRhMDYifQ.Zud5MylrcK71jpPX7pyOaA', {
    attribution: 'Map data © <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox/streets-v11',
    tileSize: 512,
    zoomOffset: -1,
    accessToken: 'your.mapbox.access.token'
}).addTo(mymap);
		
		
        var marker = L.marker([34.528542, -83.986294]).addTo(mymap)
        .bindPopup(
            'UNG Dahlonega'
        );
        //penguins
        var marker = L.marker([40.43944, -79.98917]).addTo(mymap)
        .bindPopup(
            'Pittsburgh Penguins, PPG Paints Arena, Metropolitan Division'
        );
        //nashville
        var marker = L.marker([36.15917, -86.77861]).addTo(mymap)
        .bindPopup(
            'Nashville Predators, Bridgestone Arena, Central Division'
        );
        //Senators
        var marker = L.marker([45.29694, -75.92722]).addTo(mymap)
        .bindPopup(
            'Ottawa Senators, Canadian Tire Centre, Atlantic Division'
        );
        //Stars
        var marker = L.marker([32.79056, -96.81028]).addTo(mymap)
        .bindPopup(
            'Dallas Stars, American Airlines Center, Central Division'
        );
        //panthers
        var marker = L.marker([26.15833, -80.32556]).addTo(mymap)
        .bindPopup(
            'Florida Panthers, BB&T Center, Atlantic Division'
        );
        //canadiens
        var marker = L.marker([45.49611,-73.56944]).addTo(mymap)
        .bindPopup(
            'Montreal Canadiens, Bell Centre, Atlantic Division'
        );
        //leafs
        var marker = L.marker([43.64333,-79.37917]).addTo(mymap)
        .bindPopup(
            'Toronto Maple Leafs, Air Canada Centre, Atlantic Division'
        );
        //sabres
        var marker = L.marker([42.875,-78.87639]).addTo(mymap)
        .bindPopup(
            'Buffalo Sabres, First Niagara Center, Atlantic Division'
        );
        //coyotes
        var marker = L.marker([33.53194,-112.26111]).addTo(mymap)
        .bindPopup(
            'Arizona Coyotes, Jobing.com Arena, Pacific'
        );
        //jets
        var marker = L.marker([49.89278, -97.14361]).addTo(mymap)
        .bindPopup(
            'Winnipeg Jets, Bell MTS Place, Central Division'
        );
        //ducks
        var marker = L.marker([33.80778,-117.87667]).addTo(mymap)
        .bindPopup(
            'Anahein Ducks, Honda Center, Pacific Division'
        );
        //red wings
        var marker = L.marker([42.32528,-83.05139]).addTo(mymap)
        .bindPopup(
            'Detroit Red Wings, Joe Loius Arena, Atlantic Division'
        );
        //islanders
        var marker = L.marker([40.72278, -73.59056]).addTo(mymap)
        .bindPopup(
            'New York Islanders, Nassau Veterens Memorial, Metrolitan Division'
        );
        //avalanche
        var marker = L.marker([39.74861,-105.0075]).addTo(mymap)
        .bindPopup(
            'Colorado Avalanche, Pepsi Center, Central Division'
        );
        //blue jackets
        var marker = L.marker([39.9692833,-83.0061111]).addTo(mymap)
        .bindPopup(
            'Columbus Blue Jackets, Nationwide Center, Metropolitan Division'
        );
        //oilers
        var marker = L.marker([53.57139,-113.45611]).addTo(mymap)
        .bindPopup(
            'Edmontom Oilers, Rexall Place. Pacific Division'
        );
        //hurricanes
        var marker = L.marker([35.80333,-78.72194]).addTo(mymap)
        .bindPopup(
            'Carolina Hurricanes, PNC Arena, Metropolitan Division'
        );
        //canucks
        var marker = L.marker([49.27778,-123.10889]).addTo(mymap)
        .bindPopup(
            'Vancouver Canucks, Rogers Arena, Pacific Division'
        );
        //flames
        var marker = L.marker([51.0375,-114.05194]).addTo(mymap)
        .bindPopup(
            'Calgary Flames, ScotiaBank Saddledome, Pacific Division'
        );
        //sharks
        var marker = L.marker([37.33278,-121.90111]).addTo(mymap)
        .bindPopup(
            'San Jose Sharks, SAP Center, Pacific Division'
        );
        //devils
        var marker = L.marker([40.73361,-74.17111]).addTo(mymap)
        .bindPopup(
            'New Jersey Devils, Prudential Center, Metropolitan Division'
        );
        //blues
        var marker = L.marker([38.62667,-90.2025]).addTo(mymap)
        .bindPopup(
            'St Louis Blues, Scottrade Center, Central Division'
        );
        //lightning
        var marker = L.marker([27.94278,-82.45194]).addTo(mymap)
        .bindPopup(
            'Tampa Bay Lighting, Tampa Bay Times Forum, Atlantic Division'
        );
        //kings
        var marker = L.marker([34.04306,-118.26722]).addTo(mymap)
        .bindPopup(
            'Los Angeles Kings, Staples Center, Pacific Division'
        );
        //rangers
        var marker = L.marker([40.75056,-73.99361]).addTo(mymap)
        .bindPopup(
            'New York Rangers, Madison Square Garden, Metropolitan Division'
        );
        //blackhawks
        var marker = L.marker([41.88056,-87.67417]).addTo(mymap)
        .bindPopup(
            'Chicago Blackhawks, United Center, Central Division'
        );
        //wild
        var marker = L.marker([44.94472,-93.10111]).addTo(mymap)
        .bindPopup(
            'Minnesota Wild, Xcel Energy Center, Central Division'
        );
        //flyers
        var marker = L.marker([39.90111,-75.17194]).addTo(mymap)
        .bindPopup(
            'Philadelphia Flyers, Wells Fargo Center, Metropolitan'
        );
        //caps
        var marker = L.marker([38.89806,-77.02083]).addTo(mymap)
        .bindPopup(
            'Washington Capitals, Verizon Center, Metropolitan Division'
        );
        //bruins
        var marker = L.marker([42.3663028,-71.0622278]).addTo(mymap)
        .bindPopup(
            'Boston Bruins, TD Garden, Atlantic Division'
        );

		var popup = L.popup();

function onMapClick(e) {
    popup
        .setLatLng(e.latlng)
        .setContent("You clicked the map at " + e.latlng.toString())
        .openOn(mymap);
}

mymap.on('click', onMapClick);
		
		
	</script>
	
</body>