<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Term Project</title>
</head>

<body>
	
	<header>
	<div class ="topnav">
		
	
	 
		 <ul>
			 <li>
				 <a href="finalHome.php">Home</a>
			 </li>
			 
			 <li>
				 <a href="winnJets.php">Winnipeg Jets</a>
			 </li>
			 
			 <li>
				 <a href="index(calling).php">Ajax</a>
			 </li>
			 
			 <li>
				 <a href="secure.php">About you</a>
			 </li>
			 
			 <li>
				 <a href="APItest.php">Sports!</a>
			 </li>
			 
			 <li>
				 <a href="API2.php">Hockey Map</a>
			 </li>
			 <li>
				 <a href = "logout.php">Logout</a>
</li>
		 
		 
		 
		 </ul>
		 
		
		 </div>
		
		
		
		
		</div>
	</header>

	
	
	 
	
	
</body>
</html>