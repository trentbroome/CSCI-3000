<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>footer</title>
</head>

<body>
	<div class="footerstyle">
	  <a class="footlink" href="https://docs.google.com/document/d/1sJ9YDDvs41j7CWUoD7eDQiEkkp5Huf7T9FTgH0jT_xI/edit?usp=sharing" target="_blank">My Resume</a>
  <a class="footlink" href="https://www.twitter.com/t_broome17" target="_blank">Twitter</a>
  <a class="footlink" href="https://www.linkedin.com/in/trent-broome-a0450617a/" target="_blank">LinkedIn</a></div>
</body>
</html>