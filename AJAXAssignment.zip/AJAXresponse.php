<?

$hostnameORip = "198.71.225.54:3306";
$databaseName = "ajaxDatabase";
$username = "ajax";
$password = "_Tyxx375";
$connectionString = "mysql:host=".$hostnameORip.";dbname=".$databaseName.";";
global $db;
try{
    $db = new PDO($connectionString, $username, $password);
 }catch(Exception $e){
    echo "<pre>".print_r($e, true)."</pre>";//this should give you any errors that occurred trying to connect to the database
 }

if(isset($_GET['type']) && $_GET['type']=="json")
{
	$term = $_GET['q'];
	$query = $db->query("SELECT * FROM customers WHERE name='$term'");
	if ($query)
	{
	$result = $query->fetch(PDO::FETCH_ASSOC);
	$arr['name'] = $result['name'];
	$arr['city'] = $result['city'];
	$arr['state'] = $result['state'];
	echo json_encode($result);
	}
	else
	{
		echo json_encode(array('data'=>$query));
	}
}
else
{
	$term = $_GET['q'];
	$query = $db->query("SELECT * FROM customers WHERE name='$term'");
	if ($query)
	{
	$result = $query->fetch(PDO::FETCH_ASSOC);
	//echo $db;
		?>
		HTML<table id='select'class = 'steelBlueCols'>
			<thead>
				<tr>
					<th>ID</th>
					<th>Name</th>
					<th>City</th>
					<th>State</th>
				 </tr>
			 </thead>
			
		<tbody>
				<tr>
					<td><?php echo $result['id']?></td>
					<td><?php echo $result['name'];?></td>
					<td><?php echo $result['city'];?></td>
					<td><?php echo $result['state'];?></td>
				</tr>
			</tbody>
	</table>	
<?
	}
	else
	{
		echo "Not found";
	}
}
?>
