<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Form Handling</title>
<link rel="stylesheet" type="text/css" href="phpCSS.css"/>
</head>
<body>
<?php
	$complete = true;
	if(isset($_POST["submitButton"]))//submit button was clicked
	{
		echo "form submitted<br>";
		$errors = "";
		if(isset($_POST["first"]) && strlen(trim($_POST["first"])) > 0)
		{
			//successful validation
            echo "first name submitted";
		}
		else
		{
            $errors .= "First name not completed<br>";
		}
		if(isset($_POST["last"]) && strlen(trim($_POST["last"])) > 0)
		{
			//successful validation
			echo "last name submitted";
		}
		else
		{
            $errors .= "Last name not completed<br>";
		}
		if(isset($_POST["year"]) && is_numeric($_POST["year"]) && $_POST["year"] >= 10 && $_POST["year"] <= 10)
		{
			//successful validation
			echo "year submitted";
		}
		else
		{
			//$errors .= "year is not in required range<br>";
		}
		
		//all validation steps complete
		if(strlen($errors) > 0)
		{
			echo "<div class='errors'>";
			echo $errors;
			echo "</div>";
		}
		else
		{
			echo "No errors in submission";//insert into database
		}
		
		if(isset($_POST['job']))
		{
            echo "Job type submitted!";
		}
        $java_status = '';
        $python_status = '';
    
        if (isset($_POST['Submit1'])) {
             $selected_radio = $_POST['language'];
    
             if ($selected_radio == 'java') {
                    $java_status = 'checked';
              }else if ($selected_radio == 'Python') {
                    $python_status = 'checked';
              }
        }
	}
		else
		{
			$complete = false;
		}
	
	?>
	

	<form action="" method="post">
	
		<label for="first">First Name</label>
		<input type="text" name="first" id="first" 
			   value="">
		<br>
		
		<label for="last">Last Name</label>
		<input type="text" name="last" id="last"
			   value="">
        <br>
        <label for="last">year</label>
		<input type="number" name="year" id="year" min="-10000000" max="10000000"
			   value="<? echo (isset($_POST['year']))?$_POST['year']:""; ?>">
		<br>
		<label for="last">Computer Science Jobs</label>
        <select name = "job">
            <option value = "Software Developer">Software Developer</option>
            <option value = "Network Analyst">Network Analyst</option>
            <option value = "Security Analyst">Security Analyst</option>
            <option value = "Database Admin">Database Admin</option>
        </select>
        <br>
        <label>Language you know: </label>
        <input type="radio" name = "languages" id="languages" value = "Java">
        <?PHP print $java_status; ?>
        Java
        <input type="radio" name = "languages" id="languages"value = "Python">
        <?PHP print $python_status; ?>
        Python
		<input type="submit" name="submitButton" value="Submit Form">
    </form>
    <?php if ($complete){ ?>
<table class="table table-striped table-dark">
        <thead>
          <tr>
            <th scope="col">First name</th>
            <th scope="col">Last Name</th>
            <th scope="col">School year </th>
            <th scope="col">Job title</th>
            <th scope="col">Coding Language</th>

          </tr>
        </thead>
        <tbody>
          <tr>
    <td><?php echo $_POST['first']; ?></td>
    <td><?php echo $_POST['last']; ?></td>
    <td><?php echo $_POST['year']; ?></td>
    <td><?php echo $_POST['job']; ?></td>
    <td><?php echo $_POST['languages']; ?></td>
          </tr>
<?php } ?>
</body>
</html>
